
🎧 Assets Folder

Add your resources here:
- darkVillage.jpg (background image)
- whisper.mp3 (creepy whisper sound)
- scream.mp3 (optional scream sound)

Make sure to include these in your Swift Playgrounds Resources for the game to function properly.
