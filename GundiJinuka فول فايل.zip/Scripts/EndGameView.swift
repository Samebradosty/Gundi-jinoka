
import SwiftUI

struct EndGameView: View {
    var body: some View {
        VStack(spacing: 20) {
            Text("🔚 کۆتایی")
                .font(.title)
                .foregroundColor(.yellow)
                .bold()

            Text("""
🎉 پیرۆزە! سحری گوند شکاندی.
🙏 سوپاس بۆ یاریکردنت.

بەخێربێیت بۆ بەرزکردنەوەی یارییەکانی کوردی.

👤 دروستکراو: Sami Bradosty
💸 پشتیوانی: Fastpay / FiB: 07507954528
""")
                .multilineTextAlignment(.center)
                .foregroundColor(.white)
                .padding()
        }
        .padding()
        .background(Color.black)
        .edgesIgnoringSafeArea(.all)
    }
}
