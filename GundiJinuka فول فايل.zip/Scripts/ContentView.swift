
import SwiftUI
import AVFoundation

struct ContentView: View {
    @State private var showPuzzle = false
    @State private var message = "👣 بەخێربێیت بۆ گوندی جنوكة..."

    var body: some View {
        ZStack {
            Image("darkVillage")
                .resizable()
                .edgesIgnoringSafeArea(.all)

            VStack(spacing: 20) {
                Text(message)
                    .padding()
                    .background(Color.black.opacity(0.6))
                    .foregroundColor(.green)
                    .cornerRadius(10)

                Button(action: {
                    playSound(name: "whisper")
                    showPuzzle = true
                    message = "🔐 پەزڵەکە دەستی پێکرد..."
                }) {
                    Text("دەست پێ بکە")
                        .padding()
                        .background(Color.red)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }

                if showPuzzle {
                    PuzzleOneView()
                }
                
                Text("""
🎮 یارییەکە دروستکراوە لەلایەن Sami Bradosty

🙏 سوپاس بۆ تاقیکردنەوەی یارییەکە
💸 پشتیوانی:
FastPay & FiB: 07507954528

#گوندی_جنوكة #یاری_کوردی #SamiBradosty
""")
                .foregroundColor(.gray)
                .padding()
            }
            .padding()
        }
    }
}
