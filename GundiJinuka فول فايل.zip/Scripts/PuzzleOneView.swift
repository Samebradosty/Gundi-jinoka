
import SwiftUI

struct PuzzleOneView: View {
    @State private var guess = ""
    @State private var result = ""
    let answer = "4"

    var body: some View {
        VStack {
            Text("ژمارەی نهێنی لە نێوان ١ و ٦ ـە...")
            TextField("ژمارەکەت بنووسە", text: $guess)
                .keyboardType(.numberPad)
                .padding()
                .background(Color.white)
                .cornerRadius(10)

            Button("پشکنین") {
                if guess == answer {
                    result = "✅ گەیشتیت بە ژمارەی ڕاست!"
                } else {
                    result = "❌ هەڵە، هەوڵێکی تر بده‌."
                }
            }
            .padding()
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(10)

            Text(result)
                .padding()
                .foregroundColor(.yellow)
        }
        .padding()
        .background(Color.black.opacity(0.6))
        .cornerRadius(10)
    }
}
