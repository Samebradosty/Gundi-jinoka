
import SwiftUI

@main
struct GundiJinukaApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView {
                IntroView()
            }
        }
    }
}
