
import SwiftUI

struct IntroView: View {
    var body: some View {
        VStack(spacing: 20) {
            Text("🧙‍♂️ چیرۆکێکی ترسناک")
                .font(.largeTitle)
                .foregroundColor(.red)
                .bold()

            Text("""
لێرە دەست پێدەکەیت بە چیرۆکی مورشید، 
کە دەچێتە گوندێکی بێ ئاوات بۆ یارمەتی، 
بەڵام ئەم گوندە لە لایەن جنییەوە سحرکراوە...
""")
                .multilineTextAlignment(.center)
                .foregroundColor(.white)
                .padding()

            NavigationLink(destination: ContentView()) {
                Text("دەست پێ بکە")
                    .padding()
                    .background(Color.green)
                    .foregroundColor(.black)
                    .cornerRadius(12)
            }
        }
        .padding()
        .background(Color.black)
        .edgesIgnoringSafeArea(.all)
    }
}
