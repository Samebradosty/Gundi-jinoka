
import Foundation

class GameState: ObservableObject {
    @Published var puzzleSolved = false
}
