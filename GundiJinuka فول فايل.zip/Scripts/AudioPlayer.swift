
import AVFoundation

var player: AVAudioPlayer?

func playSound(name: String) {
    if let path = Bundle.main.path(forResource: name, ofType:"mp3") {
        let url = URL(fileURLWithPath: path)
        do {
            player = try AVAudioPlayer(contentsOf: url)
            player?.play()
        } catch {
            print("❌ هەڵە لە پەخشکردنی دەنگ.")
        }
    }
}
