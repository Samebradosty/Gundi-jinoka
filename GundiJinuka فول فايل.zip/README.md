
# Gundi Jinuka - Kurdish Horror Game for iOS

Welcome to the Swift Playgrounds version of the game "Gundi Jinuka".
This project includes a dark mysterious village where the player must solve puzzles, listen to demonic whispers, and explore until the curse is broken.

## Features
- Full Kurdish UI and messages
- Realistic audio system with whispers
- Puzzle system
- Ready to export from iOS

## Developed by
**Sami Bradosty**
FastPay/FIB: 07507954528

## Note
Don't forget to add audio/image files into Resources:
- darkVillage.jpg
- whisper.mp3
- scream.mp3
